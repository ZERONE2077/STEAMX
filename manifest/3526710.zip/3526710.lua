-- 3526710's Lua and Manifest Created by Hubcap Manifest
-- Everything is Crab
-- Created: August 20, 2026 at 09:27:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3526710) -- Everything is Crab
-- MAIN APP DEPOTS
addappid(3526711, 1, "ed639283b231e8c9cf3f2809bafb053eca94f9edd0d68f2678b1b9ecbc100e83") -- Depot 3526711
setManifestid(3526711, "4745247098709093529", 1165659959)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4540950) -- Everything is Crab Supporter Pack