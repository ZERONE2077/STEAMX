-- 529340's Lua and Manifest Created by Hubcap Manifest
-- Victoria 3
-- Created: August 19, 2026 at 13:21:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 24
-- Total DLCs: 21 (2 excluded)

-- MAIN APPLICATION
addappid(529340, 1, "6bcadea95bc4140711cac04610c20ad2857088090ead96424d38bae4505042ce") -- Victoria 3
-- MAIN APP DEPOTS
addappid(529341, 1, "751bcf7f0ff0ba30922a60e32fe2c3e57e717bf3eb81cd5abe517d89a91f666a") -- Depot 529341
setManifestid(529341, "4498977168532327663", 12305380631)
addappid(529342, 1, "fbbc0f3f114625d167ca6637a358e37e90ae0e56002ad08d6cd826141487b143") -- Depot 529342
setManifestid(529342, "4691919316655930977", 395923233)
addappid(529343, 1, "f8b6d5cad4b56cdcb290338d680e0b7f5ec029a3a9c0e7801eab102c7057ed45") -- Depot 529343
setManifestid(529343, "72255550990920910", 923068212)
addappid(529344, 1, "91e2a80038ee5c6b9c10ffde8db28f2da0e1b358d499654416aea646689673a1") -- Depot 529344
setManifestid(529344, "8986793942031034561", 1871921190)
addappid(529345, 1, "35b3747b37fea27a9fd293bd654b46bb98d4bf2517f9a13d4c131d01ac0b09a3") -- Depot 529345
setManifestid(529345, "7414932565382460817", 197301833)
addappid(529346, 1, "a2b158572cb0700badd3577c2d65aab9d8401347c178d0a429b7fd4aabf0d608") -- Depot 529346
setManifestid(529346, "3116744691613779432", 388582399)
addappid(529347, 1, "657da71ab5a239544ffed593e0ab6f4d90ecc376989bdd7d3ddea676bed7321b") -- Depot 529347
setManifestid(529347, "7728389654811035422", 192460102)
-- DLCS WITH DEDICATED DEPOTS
-- Victoria 3 Victoria II Remastered Songs (AppID: 2071470)
addappid(2071470)
addappid(2071470, 1, "e46b0335eaf1a6aa7ed5b00b9051735d16d1f034c9ed1dbcc1b5743175f8d1fc") -- Victoria 3 Victoria II Remastered Songs - Depot 2071470
setManifestid(2071470, "4163203492406782527", 630473351)
-- Victoria 3 American Buildings Pack (AppID: 2071471)
addappid(2071471)
addappid(2071471, 1, "fd34c3e32f4e327d81e2929351b9ab82f5848549f7ea3173a3266335cbf6b1f5") -- Victoria 3 American Buildings Pack - Depot 2071471
setManifestid(2071471, "9120305042692556702", 102385)
-- Victoria 3 Voice of the People - Immersion Pack (AppID: 2282100)
addappid(2282100)
addappid(2282100, 1, "ca755c1431847a9c44d481bb188467c2f96ee0c26720c944acdcd1700cf69771") -- Victoria 3 Voice of the People - Immersion Pack - Depot 2282100
setManifestid(2282100, "363659807722140988", 741864781)
-- Victoria 3 Melodies for the Masses - Music Pack (AppID: 2348450)
addappid(2348450)
addappid(2348450, 1, "8321a5fc485da48cfb6fc6ac66b941c35a979cd982b719fc8facf51d2edba047") -- Victoria 3 Melodies for the Masses - Music Pack - Depot 2348450
setManifestid(2348450, "4343126498545025373", 720387105)
-- Victoria 3 French Agitators Bonus Pack (AppID: 2366580)
addappid(2366580)
addappid(2366580, 1, "8cc68dc93b4685bc2986a3fc4556a2de7f8cf1909bb2f06cd2ed94f48e2350d3") -- Victoria 3 French Agitators Bonus Pack - Depot 2366580
setManifestid(2366580, "4098566664589815689", 115189)
-- Victoria 3 Dawn of Wonder - Art Pack (AppID: 2411230)
addappid(2411230)
addappid(2411230, 1, "80fa984d828254137925cac71bd9ebeb795fa5b4bc390ad9983fe8fadbd211a3") -- Victoria 3 Dawn of Wonder - Art Pack - Depot 2411230
setManifestid(2411230, "1461629349360033550", 486617961)
-- Victoria 3 Sphere of Influence - Expansion (AppID: 2411231)
addappid(2411231)
addappid(2411231, 1, "5ba842826fdb9e68071c9771b01adc0e4be9159e92e26de331e7ac5c1d2684f9") -- Victoria 3 Sphere of Influence - Expansion - Depot 2411231
setManifestid(2411231, "6778870637804137779", 434466283)
-- Victoria 3 Colossus of the South - Region Pack (AppID: 2591240)
addappid(2591240)
addappid(2591240, 1, "773a1ca21d2e9197ce4b1ff852ae3230ac5fbab8a954a68b61ad71a13e4875b2") -- Victoria 3 Colossus of the South - Region Pack - Depot 2591240
setManifestid(2591240, "5896939596283282705", 50090565)
-- Victoria 3 Trains - Bonus Pack (AppID: 2800730)
addappid(2800730)
addappid(2800730, 1, "4e6ca866a42b0bda030de8c041ff8694d51a8ec73375dbc5e68c4d93749ae07f") -- Victoria 3 Trains - Bonus Pack - Depot 2800730
setManifestid(2800730, "5050073985265929023", 21761918)
-- Victoria 3 Pivot of Empire - Immersion Pack (AppID: 3174360)
addappid(3174360)
addappid(3174360, 1, "fd9adc2a5fc66fba32852fcc4584ab6ee87ca061d6a03ba3a9c262baed00dd8a") -- Victoria 3 Pivot of Empire - Immersion Pack - Depot 3174360
setManifestid(3174360, "1036159294070605185", 359015218)
-- Victoria 3 Charters of Commerce - Mechanics Pack (AppID: 3450170)
addappid(3450170)
addappid(3450170, 1, "10d073b22eb3123a70c012b6b9ebea935c6fff13e7fb6652e7e7636566ba062d") -- Victoria 3 Charters of Commerce - Mechanics Pack - Depot 3450170
setManifestid(3450170, "1859415655471258101", 53721652)
-- Victoria 3 National Awakening - Immersion Pack (AppID: 3562730)
addappid(3562730)
addappid(3562730, 1, "ed6a84a44c1e43437202fc093e173ce8cb2ead8463df1a694bf43bd2e99a9988") -- Victoria 3 National Awakening - Immersion Pack - Depot 3562730
setManifestid(3562730, "5018939423623213493", 495179751)
-- Victoria 3 Songs of the Homeland - Music Pack (AppID: 3562810)
addappid(3562810)
addappid(3562810, 1, "e3554bdbd47ebd858dfd124dfbda63f44ee18ce89de8574e8e7dbdb0d7441a07") -- Victoria 3 Songs of the Homeland - Music Pack - Depot 3562810
setManifestid(3562810, "8968706433718035952", 416648592)
-- Victoria 3 Iberian Twilight - Immersion Pack (AppID: 3562890)
addappid(3562890)
addappid(3562890, 1, "a94dbe1edbe6d6570aa59dc67513830a4c712703306c40afcc9238c47b741d26") -- Victoria 3 Iberian Twilight - Immersion Pack - Depot 3562890
setManifestid(3562890, "6177428406241237836", 364105711)
-- Victoria 3 Trade Ships - Bonus Pack (AppID: 3562940)
addappid(3562940)
addappid(3562940, 1, "6fc91d1743fbec84b8887e3092e4c473292d0dbc973bb31ea812805e28f7ea50") -- Victoria 3 Trade Ships - Bonus Pack - Depot 3562940
setManifestid(3562940, "4588768850590574248", 17819947)
-- Victoria 3 Warships - Bonus Pack (AppID: 4314640)
addappid(4314640)
addappid(4314640, 1, "de6a7f79a9b77028620bdb00a4d9029076f2e378750404aa12420eab405c7288") -- Victoria 3 Warships - Bonus Pack - Depot 4314640
setManifestid(4314640, "6866145312939114949", 76584007)
-- Victoria 3 The Great Wave - Expansion (AppID: 4314650)
addappid(4314650)
addappid(4314650, 1, "08f910d38b72a83f8f28d324c6d95fe6514ed4c39ee8b5c8b5e7bb1541218d7e") -- Victoria 3 The Great Wave - Expansion - Depot 4314650
setManifestid(4314650, "1572040182768359", 709278016)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2071472) -- Victoria 3 - Expansion Pass
addappid(3563050) -- Victoria 3 Expansion Pass 2
addappid(3596990) -- Victoria 3 Ultimate Bundle
addappid(4314630) -- Victoria 3 Volume 3
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4314660) -- Victoria 3: State and Revolution - Immersion Pack (unreleased)
-- addappid(4314670) -- Victoria 3: Century of Strife - Immersion Pack (unreleased)